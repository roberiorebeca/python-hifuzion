import Vue from 'vue'
import Toolbar from './Toolbar'

Vue.component('hfz-menu', Toolbar)
